import { Card, CardContent } from './ui/card';
import { Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const reviews = [
  {
    id: 1,
    name: "Amina Benali",
    location: "Casablanca",
    rating: 5,
    comment: "Séjour absolument parfait ! L'accueil chaleureux, les chambres impeccables et la vue sur l'océan magnifique. Le personnel est aux petits soins. Je recommande vivement cet hôtel pour un séjour authentique à Safi.",
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b017?w=150&q=80"
  },
  {
    id: 2,
    name: "Jean-Pierre Martin",
    location: "Lyon, France",
    rating: 5,
    comment: "Excellent rapport qualité-prix ! L'hôtel Assif nous a conquis par son charme marocain authentique et ses services de qualité. Le petit-déjeuner était délicieux avec des produits locaux. Une adresse à retenir !",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&q=80"
  },
  {
    id: 3,
    name: "Fatima Al-Rashid",
    location: "Rabat",
    rating: 5,
    comment: "Week-end en famille réussi ! Les enfants ont adoré la piscine et nous avons apprécié le calme et la propreté des lieux. L'emplacement est parfait pour découvrir Safi. Merci à toute l'équipe pour leur professionnalisme.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&q=80"
  }
];

export default function ReviewsSection() {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Avis de nos Clients
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Découvrez ce que nos clients pensent de leur séjour à l'Hôtel Assif Safi.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review) => (
            <Card key={review.id} className="shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                {/* Étoiles */}
                <div className="flex justify-center mb-4">
                  {renderStars(review.rating)}
                </div>

                {/* Commentaire */}
                <p className="text-gray-700 mb-6 text-center italic">
                  "{review.comment}"
                </p>

                {/* Profil client */}
                <div className="flex items-center justify-center space-x-4">
                  <ImageWithFallback
                    src={review.image}
                    alt={review.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="text-center">
                    <h4 className="font-semibold text-gray-900">{review.name}</h4>
                    <p className="text-sm text-gray-500">{review.location}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Statistiques */}
        <div className="mt-16 bg-blue-50 rounded-xl p-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-blue-800 mb-2">4.8/5</div>
              <div className="text-gray-600">Note moyenne</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-800 mb-2">250+</div>
              <div className="text-gray-600">Avis positifs</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-800 mb-2">95%</div>
              <div className="text-gray-600">Taux de satisfaction</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-800 mb-2">85%</div>
              <div className="text-gray-600">Clients fidèles</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}