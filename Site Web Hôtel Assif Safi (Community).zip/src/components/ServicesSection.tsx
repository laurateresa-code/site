import { Wifi, Car, Plane, Coffee, Waves, MapPin, Utensils, Shield } from 'lucide-react';

const services = [
  {
    icon: <Wifi className="w-8 h-8" />,
    title: "Wifi Gratuit",
    description: "Internet haut débit dans tout l'hôtel"
  },
  {
    icon: <Car className="w-8 h-8" />,
    title: "Parking Privé",
    description: "Stationnement sécurisé pour votre véhicule"
  },
  {
    icon: <Plane className="w-8 h-8" />,
    title: "Navette Aéroport",
    description: "Service de transfert disponible sur demande"
  },
  {
    icon: <Coffee className="w-8 h-8" />,
    title: "Petit-déjeuner Inclus",
    description: "Buffet varié avec spécialités locales"
  },
  {
    icon: <Waves className="w-8 h-8" />,
    title: "Piscine",
    description: "Piscine extérieure avec terrasse"
  },
  {
    icon: <MapPin className="w-8 h-8" />,
    title: "Accès Plage",
    description: "À quelques minutes de la plage de Safi"
  },
  {
    icon: <Utensils className="w-8 h-8" />,
    title: "Restaurant",
    description: "Cuisine marocaine et internationale"
  },
  {
    icon: <Shield className="w-8 h-8" />,
    title: "Sécurité 24h/24",
    description: "Réception et sécurité en continu"
  }
];

export default function ServicesSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Services & Équipements
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Profitez de tous nos services pour un séjour des plus agréables.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="text-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="text-blue-700 mb-4 flex justify-center">
                {service.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {service.title}
              </h3>
              <p className="text-gray-600 text-sm">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}