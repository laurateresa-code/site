import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Wifi, Car, Coffee, Tv, Waves, Phone } from 'lucide-react';

const rooms = [
  {
    id: 1,
    type: "Chambre Standard",
    price: "450",
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=500&q=80",
    description: "Chambre confortable avec tout le nécessaire pour un séjour agréable.",
    amenities: ["Wifi gratuit", "TV satellite", "Climatisation", "Salle de bain privée"],
    icons: [<Wifi key="wifi" className="w-4 h-4" />, <Tv key="tv" className="w-4 h-4" />]
  },
  {
    id: 2,
    type: "Chambre Confort",
    price: "650",
    image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=500&q=80",
    description: "Espace plus spacieux avec balcon et vue partielle sur la mer.",
    amenities: ["Wifi gratuit", "TV satellite", "Mini-bar", "Balcon", "Vue mer partielle"],
    icons: [<Wifi key="wifi" className="w-4 h-4" />, <Tv key="tv" className="w-4 h-4" />, <Waves key="waves" className="w-4 h-4" />],
    popular: true
  },
  {
    id: 3,
    type: "Suite Premium",
    price: "950",
    image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=500&q=80",
    description: "Suite luxueuse avec salon séparé et vue panoramique sur l'océan.",
    amenities: ["Wifi gratuit", "TV satellite", "Mini-bar", "Salon séparé", "Vue océan", "Service en chambre"],
    icons: [<Wifi key="wifi" className="w-4 h-4" />, <Tv key="tv" className="w-4 h-4" />, <Waves key="waves" className="w-4 h-4" />, <Coffee key="coffee" className="w-4 h-4" />]
  }
];

export default function RoomsSection() {
  return (
    <section id="chambres" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Nos Chambres
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Choisissez parmi nos différents types de chambres, toutes conçues pour votre confort et votre bien-être.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {rooms.map((room) => (
            <Card key={room.id} className="relative overflow-hidden hover:shadow-lg transition-shadow">
              {room.popular && (
                <Badge className="absolute top-4 right-4 z-10 bg-red-700 text-white">
                  Populaire
                </Badge>
              )}
              
              <CardHeader className="p-0">
                <ImageWithFallback
                  src={room.image}
                  alt={room.type}
                  className="w-full h-56 object-cover"
                />
              </CardHeader>
              
              <CardContent className="p-6">
                <CardTitle className="text-xl mb-3">{room.type}</CardTitle>
                <p className="text-gray-600 mb-4">{room.description}</p>
                
                <div className="space-y-2 mb-4">
                  {room.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center text-sm text-gray-700">
                      {room.icons[index % room.icons.length]}
                      <span className="ml-2">{amenity}</span>
                    </div>
                  ))}
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-2xl font-bold text-blue-800">{room.price} MAD</span>
                    <span className="text-gray-500">/nuit</span>
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="p-6 pt-0">
                <Button 
                  className="w-full bg-red-700 hover:bg-red-800 text-white"
                  onClick={() => document.getElementById('reservation')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  Réserver cette chambre
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}