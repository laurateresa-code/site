import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';

const galleryImages = [
  {
    src: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80",
    caption: "Façade de l'hôtel au coucher du soleil"
  },
  {
    src: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800&q=80",
    caption: "Chambre élégamment décorée"
  },
  {
    src: "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?w=800&q=80",
    caption: "Salle de bain moderne et spacieuse"
  },
  {
    src: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&q=80",
    caption: "Terrasse avec vue panoramique"
  },
  {
    src: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&q=80",
    caption: "Restaurant avec cuisine authentique"
  },
  {
    src: "https://images.unsplash.com/photo-1505142468610-359e7d316be0?w=800&q=80",
    caption: "Accès privilégié à la plage"
  }
];

export default function GallerySection() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextImage = () => {
    setCurrentIndex((prev) => (prev + 1) % galleryImages.length);
  };

  const prevImage = () => {
    setCurrentIndex((prev) => (prev - 1 + galleryImages.length) % galleryImages.length);
  };

  return (
    <section id="galerie" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Galerie Photo
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Découvrez en images l'atmosphère unique de notre hôtel.
          </p>
        </div>

        {/* Slider principal */}
        <div className="relative max-w-4xl mx-auto mb-8">
          <div className="relative aspect-video overflow-hidden rounded-lg">
            <ImageWithFallback
              src={galleryImages[currentIndex].src}
              alt={galleryImages[currentIndex].caption}
              className="w-full h-full object-cover"
            />
            
            {/* Contrôles */}
            <Button
              onClick={prevImage}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 hover:bg-opacity-70 text-white rounded-full p-2"
            >
              <ChevronLeft className="w-6 h-6" />
            </Button>
            <Button
              onClick={nextImage}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 hover:bg-opacity-70 text-white rounded-full p-2"
            >
              <ChevronRight className="w-6 h-6" />
            </Button>

            {/* Caption */}
            <div className="absolute bottom-4 left-4 right-4 bg-black bg-opacity-50 text-white p-4 rounded">
              <p className="text-center">{galleryImages[currentIndex].caption}</p>
            </div>
          </div>

          {/* Indicateurs */}
          <div className="flex justify-center mt-4 space-x-2">
            {galleryImages.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-blue-600' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Miniatures */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {galleryImages.map((image, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`relative aspect-square overflow-hidden rounded-lg transition-opacity ${
                index === currentIndex ? 'ring-2 ring-blue-600' : 'hover:opacity-80'
              }`}
            >
              <ImageWithFallback
                src={image.src}
                alt={image.caption}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}