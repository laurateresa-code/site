import { ImageWithFallback } from './figma/ImageWithFallback';

export default function AboutSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Texte */}
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Découvrez l'Hôtel Assif Safi
            </h2>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              Situé au cœur de Safi, l'Hôtel Assif vous accueille dans un cadre chaleureux et authentique. 
              Notre établissement allie le charme marocain traditionnel au confort moderne, offrant une 
              expérience unique à nos clients.
            </p>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Que vous soyez en voyage d'affaires, en vacances en famille ou en escapade romantique, 
              notre équipe dévouée s'engage à rendre votre séjour inoubliable avec des services 
              personnalisés et une hospitalité authentiquement marocaine.
            </p>
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-800 mb-2">25+</div>
                <div className="text-gray-600">Années d'expérience</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-800 mb-2">50+</div>
                <div className="text-gray-600">Chambres confortables</div>
              </div>
            </div>
          </div>

          {/* Images */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=500&q=80"
                alt="Intérieur élégant de l'hôtel"
                className="w-full h-64 object-cover rounded-lg shadow-lg"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=500&q=80"
                alt="Terrasse avec vue mer"
                className="w-full h-48 object-cover rounded-lg shadow-lg"
              />
            </div>
            <div className="mt-8">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=500&q=80"
                alt="Salon traditionnel marocain"
                className="w-full h-72 object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}