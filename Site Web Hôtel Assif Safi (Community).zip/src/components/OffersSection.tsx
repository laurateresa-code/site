import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Heart, Users, Clock, Phone } from 'lucide-react';

const offers = [
  {
    id: 1,
    title: "Week-end Romantique",
    description: "Escapade parfaite pour les couples avec dîner aux chandelles et spa",
    price: "1200",
    duration: "2 nuits",
    includes: ["Champagne à l'arrivée", "Dîner romantique", "Petit-déjeuner au lit", "Accès spa"],
    icon: <Heart className="w-8 h-8 text-red-600" />,
    color: "bg-red-50 border-red-200"
  },
  {
    id: 2,
    title: "Famille Heureuse",
    description: "Forfait idéal pour les familles avec activités et repas inclus",
    price: "2500",
    duration: "3 nuits",
    includes: ["Chambre familiale", "Tous les repas", "Activités enfants", "Piscine privée"],
    icon: <Users className="w-8 h-8 text-blue-600" />,
    color: "bg-blue-50 border-blue-200",
    popular: true
  },
  {
    id: 3,
    title: "Early Bird",
    description: "Réservez 30 jours à l'avance et bénéficiez de 25% de réduction",
    price: "25%",
    duration: "Toute l'année",
    includes: ["25% de réduction", "Petit-déjeuner offert", "Wifi gratuit", "Check-in prioritaire"],
    icon: <Clock className="w-8 h-8 text-green-600" />,
    color: "bg-green-50 border-green-200"
  }
];

export default function OffersSection() {
  return (
    <section id="offres" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Offres Spéciales & Forfaits
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Profitez de nos offres exclusives pour rendre votre séjour encore plus mémorable.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {offers.map((offer) => (
            <Card key={offer.id} className={`relative ${offer.color} hover:shadow-lg transition-shadow`}>
              {offer.popular && (
                <Badge className="absolute top-4 right-4 z-10 bg-blue-700 text-white">
                  Populaire
                </Badge>
              )}
              
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-4">
                  {offer.icon}
                </div>
                <CardTitle className="text-2xl">{offer.title}</CardTitle>
                <p className="text-gray-600 mt-2">{offer.description}</p>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="text-center">
                  <span className="text-3xl font-bold text-gray-900">
                    {offer.price === "25%" ? offer.price : `${offer.price} MAD`}
                  </span>
                  <div className="text-gray-500 mt-1">{offer.duration}</div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900">Inclus :</h4>
                  {offer.includes.map((item, index) => (
                    <div key={index} className="flex items-center text-sm text-gray-700">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
                
                <Button 
                  className="w-full bg-red-700 hover:bg-red-800 text-white mt-6"
                  onClick={() => window.location.href = 'tel:+212524464025'}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Réserver par téléphone
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}