import { Button } from './ui/button';
import { Phone, ArrowDown } from 'lucide-react';

export default function HeroSection() {
  return (
    <section id="accueil" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Image de fond avec plusieurs couches pour un effet professionnel */}
      <div className="absolute inset-0">
        {/* Image principale */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat transform scale-105"
          style={{
            backgroundImage: `url(https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=1920&q=80)`,
          }}
        />
        
        {/* Overlay avec dégradé sophistiqué */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-black/60"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/50"></div>
        
        {/* Effet de particules/texture subtile */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[length:50px_50px]"></div>
      </div>

      {/* Contenu principal */}
      <div className="relative z-10 text-center text-white max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Badge de bienvenue */}
        <div className="inline-flex items-center px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 mb-8">
          <span className="text-sm font-medium text-white/90">✨ Bienvenue au Maroc authentique</span>
        </div>

        {/* Titre principal avec effet de profondeur */}
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
          <span className="block text-white drop-shadow-2xl">Bienvenue à l'</span>
          <span className="block bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent drop-shadow-2xl">
            Hôtel Assif Safi
          </span>
        </h1>

        {/* Sous-titre élégant */}
        <h2 className="text-xl md:text-3xl mb-6 text-gray-200 drop-shadow-lg">
          Le confort et l'élégance en bord de mer
        </h2>

        {/* Description enrichie */}
        <p className="text-lg md:text-xl mb-12 text-gray-300 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
          Découvrez l'hospitalité marocaine dans un cadre d'exception où tradition et modernité se rencontrent. 
          <br className="hidden md:block" />
          Réservez facilement par téléphone ou en ligne pour une expérience inoubliable.
        </p>

        {/* Boutons CTA avec effets améliorés */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12">
          <Button 
            className="bg-blue-700 hover:bg-blue-800 text-white px-10 py-4 rounded-full text-lg font-semibold shadow-2xl transform hover:scale-105 transition-all duration-300 border border-blue-600/50 backdrop-blur-sm"
            onClick={() => document.getElementById('chambres')?.scrollIntoView({ behavior: 'smooth' })}
          >
            <ArrowDown className="w-5 h-5 mr-3" />
            Découvrir nos chambres
          </Button>
          <Button 
            className="bg-red-700 hover:bg-red-800 text-white px-10 py-4 rounded-full text-lg font-semibold shadow-2xl transform hover:scale-105 transition-all duration-300 border border-red-600/50 backdrop-blur-sm"
            onClick={() => window.location.href = 'tel:+212524464025'}
          >
            <Phone className="w-5 h-5 mr-3" />
            Réserver maintenant
          </Button>
        </div>

        {/* Informations rapides */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
            <div className="text-2xl font-bold text-blue-400 mb-1">25+</div>
            <div className="text-sm text-gray-300">Années d'excellence</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
            <div className="text-2xl font-bold text-blue-400 mb-1">50+</div>
            <div className="text-sm text-gray-300">Chambres de luxe</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
            <div className="text-2xl font-bold text-blue-400 mb-1">24/7</div>
            <div className="text-sm text-gray-300">Service client</div>
          </div>
        </div>
      </div>

      {/* Indicateur de scroll amélioré */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <div className="flex flex-col items-center">
          <span className="text-sm text-gray-300 mb-2">Découvrez plus</span>
          <ArrowDown className="w-6 h-6" />
        </div>
      </div>

      {/* Effet de vagues en bas */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg 
          viewBox="0 0 1200 120" 
          preserveAspectRatio="none" 
          className="relative block w-full h-20"
        >
          <path 
            d="M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z" 
            className="fill-white"
          />
        </svg>
      </div>
    </section>
  );
}