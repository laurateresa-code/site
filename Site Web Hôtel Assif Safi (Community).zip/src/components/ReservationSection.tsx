import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Phone, Mail, Calendar, Users } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export default function ReservationSection() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    checkin: '',
    checkout: '',
    roomType: '',
    guests: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simuler l'envoi de la demande
    toast.success('Demande de réservation envoyée avec succès! Nous vous contacterons bientôt.');
    setFormData({
      name: '',
      phone: '',
      email: '',
      checkin: '',
      checkout: '',
      roomType: '',
      guests: '',
      message: ''
    });
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="reservation" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Système de Réservation
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Réservez votre séjour facilement en ligne ou contactez-nous directement par téléphone.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Formulaire de réservation */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Demande de Réservation</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nom complet *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleChange('name', e.target.value)}
                      required
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Téléphone *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleChange('phone', e.target.value)}
                      required
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    required
                    className="mt-1"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="checkin">Date d'arrivée *</Label>
                    <Input
                      id="checkin"
                      type="date"
                      value={formData.checkin}
                      onChange={(e) => handleChange('checkin', e.target.value)}
                      required
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="checkout">Date de départ *</Label>
                    <Input
                      id="checkout"
                      type="date"
                      value={formData.checkout}
                      onChange={(e) => handleChange('checkout', e.target.value)}
                      required
                      className="mt-1"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="roomType">Type de chambre *</Label>
                    <Select value={formData.roomType} onValueChange={(value) => handleChange('roomType', value)}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Sélectionner une chambre" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="standard">Chambre Standard</SelectItem>
                        <SelectItem value="confort">Chambre Confort</SelectItem>
                        <SelectItem value="suite">Suite Premium</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="guests">Nombre de personnes *</Label>
                    <Select value={formData.guests} onValueChange={(value) => handleChange('guests', value)}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Nombre de personnes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 personne</SelectItem>
                        <SelectItem value="2">2 personnes</SelectItem>
                        <SelectItem value="3">3 personnes</SelectItem>
                        <SelectItem value="4">4 personnes</SelectItem>
                        <SelectItem value="5+">5+ personnes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="message">Message (optionnel)</Label>
                  <Textarea
                    id="message"
                    placeholder="Demandes spéciales, préférences..."
                    value={formData.message}
                    onChange={(e) => handleChange('message', e.target.value)}
                    className="mt-1 min-h-[100px]"
                  />
                </div>

                <Button type="submit" className="w-full bg-blue-700 hover:bg-blue-800 text-white py-3">
                  <Mail className="w-4 h-4 mr-2" />
                  Envoyer la demande
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Options de réservation */}
          <div className="space-y-8">
            {/* Réservation par téléphone */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-center">Réservation par Téléphone</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-6">
                  <Phone className="w-12 h-12 text-red-700 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">
                    Appelez-nous directement pour une réservation immédiate et personnalisée.
                  </p>
                </div>
                <Button 
                  className="w-full bg-red-700 hover:bg-red-800 text-white py-3 mb-4"
                  onClick={() => window.location.href = 'tel:+212524464025'}
                >
                  <Phone className="w-5 h-5 mr-2" />
                  +212 524 46 40 25
                </Button>
                <p className="text-sm text-gray-500">
                  Disponible de 8h00 à 22h00, 7j/7
                </p>
              </CardContent>
            </Card>

            {/* Informations utiles */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">Informations Utiles</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Calendar className="w-5 h-5 text-blue-700 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Check-in / Check-out</h4>
                    <p className="text-sm text-gray-600">Arrivée : 15h00 | Départ : 12h00</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Users className="w-5 h-5 text-blue-700 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Politique d'annulation</h4>
                    <p className="text-sm text-gray-600">Annulation gratuite jusqu'à 24h avant l'arrivée</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Mail className="w-5 h-5 text-blue-700 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Confirmation rapide</h4>
                    <p className="text-sm text-gray-600">Réponse sous 2 heures en moyenne</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}