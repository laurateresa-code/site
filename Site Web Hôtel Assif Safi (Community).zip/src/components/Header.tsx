import { useState } from 'react';
import { Button } from './ui/button';
import { Menu, X, Phone } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <h1 className="text-2xl font-bold text-blue-800">Hôtel Assif Safi</h1>
          </div>

          {/* Navigation Desktop */}
          <nav className="hidden md:flex space-x-8">
            <a href="#accueil" className="text-gray-700 hover:text-blue-800 transition-colors">Accueil</a>
            <a href="#chambres" className="text-gray-700 hover:text-blue-800 transition-colors">Chambres</a>
            <a href="#offres" className="text-gray-700 hover:text-blue-800 transition-colors">Offres</a>
            <a href="#galerie" className="text-gray-700 hover:text-blue-800 transition-colors">Galerie</a>
            <a href="#reservation" className="text-gray-700 hover:text-blue-800 transition-colors">Réservation</a>
            <a href="#contact" className="text-gray-700 hover:text-blue-800 transition-colors">Contact</a>
          </nav>

          {/* Bouton Réserver Desktop */}
          <div className="hidden md:block">
            <Button 
              className="bg-red-700 hover:bg-red-800 text-white px-6 py-2 rounded-full"
              onClick={() => window.location.href = 'tel:+212524464025'}
            >
              <Phone className="w-4 h-4 mr-2" />
              Réserver maintenant
            </Button>
          </div>

          {/* Menu Mobile */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-blue-800"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Menu Mobile */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-t">
              <a href="#accueil" className="block px-3 py-2 text-gray-700 hover:text-blue-800">Accueil</a>
              <a href="#chambres" className="block px-3 py-2 text-gray-700 hover:text-blue-800">Chambres</a>
              <a href="#offres" className="block px-3 py-2 text-gray-700 hover:text-blue-800">Offres</a>
              <a href="#galerie" className="block px-3 py-2 text-gray-700 hover:text-blue-800">Galerie</a>
              <a href="#reservation" className="block px-3 py-2 text-gray-700 hover:text-blue-800">Réservation</a>
              <a href="#contact" className="block px-3 py-2 text-gray-700 hover:text-blue-800">Contact</a>
              <div className="px-3 py-2">
                <Button 
                  className="w-full bg-red-700 hover:bg-red-800 text-white px-6 py-2 rounded-full"
                  onClick={() => window.location.href = 'tel:+212524464025'}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Réserver maintenant
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}