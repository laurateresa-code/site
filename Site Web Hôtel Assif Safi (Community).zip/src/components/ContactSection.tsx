import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export default function ContactSection() {
  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Contact & Localisation
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Trouvez-nous facilement au cœur de Safi et contactez-nous pour toute information.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Informations de contact */}
          <div className="space-y-8">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">Informations de Contact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-blue-700 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Adresse</h4>
                    <p className="text-gray-600">
                      Avenue Mohammed V<br />
                      46000 Safi, Maroc
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Phone className="w-6 h-6 text-blue-700 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Téléphone</h4>
                    <Button
                      variant="link"
                      className="p-0 h-auto text-blue-700 hover:text-blue-800"
                      onClick={() => window.location.href = 'tel:+212524464025'}
                    >
                      +212 524 46 40 25
                    </Button>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Mail className="w-6 h-6 text-blue-700 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Email</h4>
                    <Button
                      variant="link"
                      className="p-0 h-auto text-blue-700 hover:text-blue-800"
                      onClick={() => window.location.href = 'mailto:contact@hotelassif-safi.ma'}
                    >
                      contact@hotelassif-safi.ma
                    </Button>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Clock className="w-6 h-6 text-blue-700 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Horaires d'accueil</h4>
                    <p className="text-gray-600">
                      24h/24 - 7j/7<br />
                      Réception toujours ouverte
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Comment nous rejoindre */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">Comment nous rejoindre</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">🚗 En voiture</h4>
                  <p className="text-sm text-gray-600">
                    Parking privé gratuit disponible. L'hôtel est situé sur l'avenue principale, 
                    facilement accessible depuis l'autoroute A1.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">✈️ Depuis l'aéroport</h4>
                  <p className="text-sm text-gray-600">
                    Aéroport Mohammed V de Casablanca à 2h30 en voiture. 
                    Service de navette disponible sur réservation.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">🚌 Transports en commun</h4>
                  <p className="text-sm text-gray-600">
                    Gare routière de Safi à 10 minutes à pied. 
                    Taxis disponibles 24h/24 devant l'hôtel.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Carte Google Maps */}
          <div className="space-y-8">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">Notre Localisation</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="w-full h-96 bg-gray-200 rounded-b-lg overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3368.1234567890!2d-9.237089!3d32.299089!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzLCsDE3JzU2LjciTiA5wrAxNCcxMy41Ilc!5e0!3m2!1sfr!2sma!4v1234567890"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Localisation Hôtel Assif Safi"
                  ></iframe>
                </div>
              </CardContent>
            </Card>

            {/* Points d'intérêt */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">Points d'Intérêt à Proximité</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">🏖️ Plage de Safi</span>
                  <span className="text-sm text-blue-700">5 min à pied</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">🏛️ Musée de la Céramique</span>
                  <span className="text-sm text-blue-700">10 min à pied</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">🏰 Château de la Mer</span>
                  <span className="text-sm text-blue-700">15 min à pied</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">🛒 Médina de Safi</span>
                  <span className="text-sm text-blue-700">8 min à pied</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">🍽️ Restaurants locaux</span>
                  <span className="text-sm text-blue-700">2-5 min</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}