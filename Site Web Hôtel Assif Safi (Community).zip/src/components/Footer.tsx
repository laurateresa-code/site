import { Button } from './ui/button';
import { Phone, Mail, MapPin, Facebook, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo et description */}
          <div className="lg:col-span-2">
            <h3 className="text-2xl font-bold mb-4">Hôtel Assif Safi</h3>
            <p className="text-gray-300 mb-6 max-w-md">
              Votre destination de choix à Safi pour un séjour alliant confort moderne 
              et authenticité marocaine. Découvrez l'hospitalité traditionnelle dans 
              un cadre exceptionnel en bord de mer.
            </p>
            <div className="flex space-x-4">
              <Button variant="outline" size="icon" className="border-gray-600 text-gray-300 hover:text-white hover:bg-blue-700">
                <Facebook className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="border-gray-600 text-gray-300 hover:text-white hover:bg-blue-700">
                <Instagram className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Contact rapide */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Rapide</h4>
            <div className="space-y-3">
              <Button
                variant="ghost"
                className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-800 p-0"
                onClick={() => window.location.href = 'tel:+212524464025'}
              >
                <Phone className="w-4 h-4 mr-3" />
                +212 524 46 40 25
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start text-gray-300 hover:text-white hover:bg-gray-800 p-0"
                onClick={() => window.location.href = 'mailto:contact@hotelassif-safi.ma'}
              >
                <Mail className="w-4 h-4 mr-3" />
                contact@hotelassif-safi.ma
              </Button>
              <div className="flex items-start text-gray-300 pt-2">
                <MapPin className="w-4 h-4 mr-3 mt-1 flex-shrink-0" />
                <span className="text-sm">
                  Avenue Mohammed V<br />
                  46000 Safi, Maroc
                </span>
              </div>
            </div>
          </div>

          {/* Liens utiles */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Liens Utiles</h4>
            <div className="space-y-2">
              <a href="#chambres" className="block text-gray-300 hover:text-white transition-colors">
                Nos Chambres
              </a>
              <a href="#offres" className="block text-gray-300 hover:text-white transition-colors">
                Offres Spéciales
              </a>
              <a href="#galerie" className="block text-gray-300 hover:text-white transition-colors">
                Galerie Photo
              </a>
              <a href="#reservation" className="block text-gray-300 hover:text-white transition-colors">
                Réservation
              </a>
              <a href="#contact" className="block text-gray-300 hover:text-white transition-colors">
                Contact
              </a>
            </div>
          </div>
        </div>

        {/* Séparateur */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Hôtel Assif Safi. Tous droits réservés.
            </p>
            <div className="mt-4 md:mt-0">
              <Button 
                className="bg-red-700 hover:bg-red-800 text-white px-6 py-2 rounded-full"
                onClick={() => window.location.href = 'tel:+212524464025'}
              >
                <Phone className="w-4 h-4 mr-2" />
                Réserver maintenant
              </Button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}