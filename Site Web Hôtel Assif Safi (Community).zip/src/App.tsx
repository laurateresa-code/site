import Header from './components/Header';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import RoomsSection from './components/RoomsSection';
import OffersSection from './components/OffersSection';
import ServicesSection from './components/ServicesSection';
import GallerySection from './components/GallerySection';
import ReservationSection from './components/ReservationSection';
import ReviewsSection from './components/ReviewsSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import { Toaster } from './components/ui/sonner';

export default function App() {
  return (
    <div className="min-h-screen">
      {/* Header fixe */}
      <Header />
      
      {/* Sections principales */}
      <main>
        <HeroSection />
        <AboutSection />
        <RoomsSection />
        <OffersSection />
        <ServicesSection />
        <GallerySection />
        <ReservationSection />
        <ReviewsSection />
        <ContactSection />
      </main>
      
      {/* Footer */}
      <Footer />
      
      {/* Toast notifications */}
      <Toaster />
    </div>
  );
}