
  # Site Web Hôtel Assif Safi (Community)

  This is a code bundle for Site Web Hôtel Assif Safi (Community). The original project is available at https://www.figma.com/design/tTVPpsfQetMsGf7Sbml4nE/Site-Web-H%C3%B4tel-Assif-Safi--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  